#include "freeling/morfo/analyzer.h"
#include "freeling/morfo/util.h"
#include "freeling/output/input_conll.h"
#include "freeling/output/output_conll.h"

#include "config.h"

using namespace std;
using namespace freeling;

//////////////   MAIN PROGRAM  /////////////////////

int main (int argc, char **argv) {

  //// set locale to an UTF8 compatible locale 
  util::init_locale(L"default");

  /// read FreeLing installation path if given, use default otherwise
  wstring ipath;
  if (argc < 2) ipath = L"/usr/local";
  else ipath = util::string2wstring(argv[1]);

  // crear output_conll
  output_conll out(L"./output.cfg");

  /// load plain text
  wstring text = L"";  
  wstring line;
  wstring prev_line = L"-";
  while (getline(wcin,line) && (prev_line != L"" || line != L"")) {
    text = text + line + L"\n";
    prev_line = line;
  }
  
  /// load analized text
  wstring an_text = L"";  
  while (getline(wcin,line))
    an_text = an_text + line + L"\n";

  wcout << text << endl;

  wcout << L"-----------------" << endl;

  wcout << an_text << endl;

  wcout << L"-----------------" << endl;

  input_conll ip;

  document doc;
  ip.input_document(an_text,doc);
  
  for (list<paragraph>::const_iterator it_p = doc.begin(); it_p != doc.end(); it_p++) {
    for (list<sentence>::const_iterator it_s = it_p->begin(); it_s != it_p->end(); it_s++) {
      const sentence & s = *it_s;
      sentence::const_iterator b_it= s.begin();
      sentence::const_iterator e_it= --s.end();
      unsigned long span_start = b_it->get_span_start();
      unsigned long span_finish = e_it->get_span_finish();

      for (int i = span_start; i < span_finish; i++) {
        wcout << text[i];
      }
      wcout << endl;
    }
  }
}